#include <stdint.h>

//Prototypes of functions

uint16_t* rezerviraj(int velikostZlogi);

void brisi(uint16_t* pomnilnik);

uint16_t* vstavi(uint16_t* pomnilnik);

void izpis(uint16_t* pomnilnik);